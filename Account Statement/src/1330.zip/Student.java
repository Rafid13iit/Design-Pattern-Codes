public class Student extends Person {
    public Student(String name, String designation, String phoneNumber) {
        super(name, designation, phoneNumber);
    }
}
