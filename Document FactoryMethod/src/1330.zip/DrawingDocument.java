public class DrawingDocument extends Document {
    @Override
    public void open() {
        System.out.println("Opening Drawing Document");
        // Add specific logic for opening a drawing document
    }

    @Override
    public void save() {
        System.out.println("Saving Drawing Document");
        // Add specific logic for saving a drawing document
    }
}