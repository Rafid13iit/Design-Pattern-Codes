interface Chair {
    void sitOn();
}