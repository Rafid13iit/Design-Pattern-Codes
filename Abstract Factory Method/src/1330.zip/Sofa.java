interface Sofa {
    void lieOn();
}