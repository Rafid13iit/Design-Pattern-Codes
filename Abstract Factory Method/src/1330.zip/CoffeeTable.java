interface CoffeeTable {
    void putCoffee();
}