class ArtDecoCoffeeTable implements CoffeeTable {
    @Override
    public void putCoffee() {
        System.out.println("Putting coffee on an ArtDeco coffee table.");
    }
}